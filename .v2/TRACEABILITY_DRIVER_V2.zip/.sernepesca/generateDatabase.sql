-- Create database
CREATE DATABASE FishingDB;
GO

USE FishingDB;
GO

-- Armador Table
CREATE TABLE Armador (
    IdArmador int NOT NULL PRIMARY KEY,
    IdTipoIdentificacion varchar(3) NOT NULL,
    Identificacion varchar(13) NOT NULL,
    Apellidos varchar(80) NULL,
    Nombres varchar(80) NULL,
    Email varchar(50) NULL,
    Celular varchar(15) NULL,
    Usuario varchar(45) NULL,
    Clave varchar(45) NULL,
    Estado varchar(5) NULL,
    FechaRegistro datetime NULL DEFAULT GETDATE(),
    FechaUltimoLogin datetime NULL,
    PermisoApp tinyint NULL DEFAULT 1,
    SoloLectura tinyint NULL DEFAULT 0,
    IdRegistro varchar(8) NULL,
    FormatoCoordenadas varchar(8) NULL DEFAULT 'DEC',
    Administrador tinyint NULL DEFAULT 0,
    RazonSocial varchar(150) NULL
);
GO

-- ArtePesca Table
CREATE TABLE ArtePesca (
    IdSector int NOT NULL,
    IdSubSector int NOT NULL,
    IdArtePesca int NOT NULL,
    Nombre varchar(45) NULL,
    Caracteristicas varchar(200) NULL,
    RegistraInicioPesca tinyint NULL DEFAULT 1,
    RegistraFinPesca tinyint NULL DEFAULT 1,
    RegistraCoordenadasInicioPesca tinyint NULL DEFAULT 0,
    RegistraCoordenadasFinPesca tinyint NULL DEFAULT 0,
    RegistraAperturaBitacora tinyint NULL DEFAULT 1,
    RegistraCierreBitacora tinyint NULL DEFAULT 1,
    RegistraCoordenadasAperturaBitacora tinyint NULL DEFAULT 1,
    RegistraCoordenadasCierreBitacora tinyint NULL DEFAULT 1,
    DeclaracionZonaPesca varchar(5) NULL DEFAULT '10',
    RegistraCantidadArte tinyint NULL DEFAULT 0,
    UnidadPeso varchar(3) NULL DEFAULT 'lb',
    CantidadMaximaLancesAbiertos int NULL DEFAULT 1,
    CantidadMaximaLancesSinRegistroCaptura int NULL DEFAULT 99,
    Estado varchar(3) NULL DEFAULT 'A',
    MostrarEnApp smallint NULL DEFAULT 1,
    PRIMARY KEY (IdSector, IdSubSector, IdArtePesca)
);
GO

-- Bitacora Table
CREATE TABLE Bitacora (
    IdBitacora int NOT NULL PRIMARY KEY,
    CodigoBitacora varchar(45) NULL,
    IdEmbarcacion int NULL,
    Bitacora nvarchar(8000) NULL,
    FechaHoraInicio datetime NOT NULL,
    FechaHoraRegistro datetime NOT NULL,
    IdArmador int NULL,
    Enviada tinyint NULL
);
GO

-- Capitan Table
CREATE TABLE Capitan (
    IdCapitan int NOT NULL PRIMARY KEY,
    IdTipoIdentificacion varchar(3) NULL,
    Identificacion varchar(15) NULL,
    Nombres varchar(80) NULL,
    Apellidos varchar(80) NULL,
    Direccion varchar(45) NULL,
    Celular varchar(15) NULL,
    Email varchar(45) NULL,
    Usuario varchar(45) NULL DEFAULT 'A',
    Clave varchar(45) NULL,
    Estado varchar(5) NULL,
    FechaRegistro datetime NULL DEFAULT GETDATE(),
    IdArmador int NULL,
    token varchar(40) NULL,
    token_password varchar(100) NULL,
    password_request int NULL DEFAULT 0
);
GO

-- CapitanEmbarcacion Table
CREATE TABLE CapitanEmbarcacion (
    IdCapitan int NOT NULL,
    IdEmbarcacion int NOT NULL,
    FechaIngreso datetime NULL DEFAULT GETDATE(),
    PRIMARY KEY (IdCapitan, IdEmbarcacion)
);
GO

-- Embarcacion Table
CREATE TABLE Embarcacion (
    IdEmbarcacion int NOT NULL PRIMARY KEY,
    IdArmador int NULL,
    Nombre varchar(100) NULL,
    Matricula varchar(45) NULL,
    PermisoPesca varchar(45) NULL,
    FechaVigenciaPermisoPesca date NULL,
    Estado varchar(5) NULL,
    FechaRegistro datetime NULL,
    Pais varchar(3) NULL DEFAULT 'EC'
);
GO

-- EmbarcacionSectorSubSectorArtePesca Table
CREATE TABLE EmbarcacionSectorSubSectorArtePesca (
    IdEmbarcacion int NOT NULL,
    IdSector int NOT NULL,
    IdSubSector int NOT NULL,
    IdArtePesca int NOT NULL,
    FechaRegistro datetime NULL DEFAULT GETDATE(),
    PRIMARY KEY (IdEmbarcacion, IdSector, IdSubSector, IdArtePesca)
);
GO

-- EspecieIncidental Table
CREATE TABLE EspecieIncidental (
    IdOrder int NOT NULL,
    IdSector int NOT NULL,
    IdSubSector int NOT NULL,
    IdArtePesca int NOT NULL,
    IdEspecieIncidental int NOT NULL,
    NombreComun varchar(45) NULL,
    NombreCientifico varchar(100) NULL,
    Grupo tinyint NULL DEFAULT 0,
    RegistraPesoCaptura tinyint NULL DEFAULT 1,
    RegistraConteoIndividual tinyint NULL DEFAULT 0,
    UnidadPeso varchar(3) NULL DEFAULT 'lb',
    MostrarEnApp tinyint NULL DEFAULT 1,
    PRIMARY KEY (IdSector, IdSubSector, IdArtePesca, IdEspecieIncidental)
);
GO

-- EspecieObjetivo Table
CREATE TABLE EspecieObjetivo (
    IdOrder int NOT NULL,
    IdSector int NOT NULL,
    IdSubSector int NOT NULL,
    IdArtePesca int NOT NULL,
    IdEspecieObjectivo int NOT NULL,
    NombreComun varchar(45) NULL,
    NombreCientifico varchar(100) NULL,
    Grupo tinyint NULL DEFAULT 0,
    RegistraPesoCaptura tinyint NULL,
    RegistraConteoIndividual tinyint NULL,
    UnidadPeso varchar(3) NULL DEFAULT 'lb',
    MostrarEnApp tinyint NULL DEFAULT 1,
    PRIMARY KEY (IdSector, IdSubSector, IdArtePesca, IdEspecieObjectivo)
);
GO

-- Puerto Table
CREATE TABLE Puerto (
    IdPuerto int NOT NULL PRIMARY KEY,
    Nombre varchar(45) NULL,
    IdRegion int NULL
);
GO

-- PuertoSectorSubSectorArtePesca Table
CREATE TABLE PuertoSectorSubSectorArtePesca (
    IdSector int NOT NULL,
    IdSubSector int NOT NULL,
    IdArtePesca int NOT NULL,
    IdPuerto int NOT NULL,
    PRIMARY KEY (IdSector, IdSubSector, IdArtePesca, IdPuerto)
);
GO

-- ResultadoLanceBitacora Table
CREATE TABLE ResultadoLanceBitacora (
    idResultadoLanceBitacora int NOT NULL PRIMARY KEY,
    idBitacora int NULL,
    codBitacora varchar(100) NULL,
    inicioBitacora datetime NULL,
    finBitacora datetime NULL,
    codPuertoInicio int NULL,
    puertoInicio varchar(100) NULL,
    codPuertoFin int NULL,
    puertoFin varchar(100) NULL,
    latitudInicio varchar(100) NULL,
    longitudInicio varchar(100) NULL,
    latitudFin varchar(100) NULL,
    longitudFin varchar(100) NULL,
    identificacionCapitan varchar(15) NULL,
    idCapitan int NULL,
    nombresCapitan varchar(80) NULL,
    apellidosCapitan varchar(80) NULL,
    emailCapitan varchar(45) NULL,
    celularCapitan varchar(15) NULL,
    direccionCapitan varchar(45) NULL,
    idEmbBEP int NULL,
    matricula varchar(45) NULL,
    tpRegistro varchar(3) NULL,
    nr_Folio int NULL,
    nombreEmbarcacion varchar(100) NULL,
    permisoPesca varchar(45) NULL,
    fechaVigenciaPermisoPesca varchar(45) NULL,
    nrLance int NULL,
    inicioLance datetime NULL,
    finLance datetime NULL,
    codArte int NULL,
    nombreArte varchar(45) NULL,
    observaciones varchar(2000) NULL,
    zonaPescaInicio varchar(100) NULL,
    capturaGrupalTotal decimal(5,2) NULL,
    latitudInicioLance varchar(100) NULL,
    longitudInicioLance varchar(100) NULL,
    latitudFinLance varchar(100) NULL,
    longitudFinLance varchar(100) NULL,
    nrLanceRecurso int NULL,
    tipoPesca varchar(1) NULL,
    nombrePesca varchar(45) NULL,
    pesoRecurso decimal(9,2) NULL,
    cantidadRecurso int NULL,
    codigoEspecie int NULL,
    nombreEspecie varchar(200) NULL,
    secuencia int NULL,
    unidadPeso varchar(45) NULL,
    nombreEspecieCientifico varchar(200) NULL,
    AvisoRecalada int NULL
);
GO

-- Sector Table
CREATE TABLE Sector (
    IdSector int NOT NULL PRIMARY KEY,
    Nombre varchar(45) NULL,
    Descripcion varchar(45) NULL,
    Ambito varchar(45) NULL
);
GO

-- SubSector Table
CREATE TABLE SubSector (
    IdSector int NOT NULL,
    IdSubSector int NOT NULL,
    Nombre varchar(45) NULL,
    Descripcion varchar(45) NULL,
    Ambito varchar(45) NULL,
    PRIMARY KEY (IdSector, IdSubSector)
);
GO

-- ZonaPesca Table
CREATE TABLE ZonaPesca (
    IdZonaPesca int NOT NULL PRIMARY KEY,
    Nombre varchar(45) NULL
);
GO

-- ZonaPescaSectorSubSectorArtePesca Table
CREATE TABLE ZonaPescaSectorSubSectorArtePesca (
    IdSector int NOT NULL,
    IdSubsector int NOT NULL,
    IdArtePesca int NOT NULL,
    IdZonaPesca int NOT NULL,
    PRIMARY KEY (IdSector, IdSubsector, IdArtePesca, IdZonaPesca)
);
GO