using Microsoft.Extensions.DependencyInjection;
using TraceabilityDriver.Services;
using TraceabilityDriver.Services.Mapping;
using TraceabilityDriver.Services.Mapping.Functions;

namespace TraceabilityDriver
{
    public class Startup
    {
        public void ConfigureServices(IServiceCollection services)
        {
            // SERVICES
            services.AddSingleton<MongoDBService>();

            // HOSTED SERVICES
            services.AddHostedService<SynchronizeService>();

            // MAPPING
            services.AddTransient<EventsTableMappingService>();
            services.AddTransient<EventsConverterService>();
            services.AddTransient<EventsMergerService>();

            // MAPPING FUNCTIONS
            services.AddSingleton<MappingFunctionFactory>();
            services.AddSingleton<DictionaryMappingFunction>();
        }
    }
} 