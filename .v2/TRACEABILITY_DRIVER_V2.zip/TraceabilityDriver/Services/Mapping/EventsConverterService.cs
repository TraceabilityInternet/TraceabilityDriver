using OpenTraceability.Models.Events;
using TraceabilityDriver.Models;
using TraceabilityDriver.Models.Mapping;

namespace TraceabilityDriver.Services;

/// <summary>
/// The service for converting common events to EPCIS events.
/// </summary>
public class EventsConverterService
{
    private readonly ILogger<EventsConverterService> _logger;

    public EventsConverterService(ILogger<EventsConverterService> logger)
    {
        _logger = logger;
    }

    /// <summary>
    /// Converts the common events to EPCIS events.
    /// </summary>
    public async Task<EPCISDocument> ConvertEventsAsync(List<CommonEvent> events)
    {
        /// TODO: Implement the logic to convert the common events to EPCIS events.
        return new EPCISDocument();
    }
}

