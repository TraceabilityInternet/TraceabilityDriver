namespace TraceabilityDriver.Services.Mapping.Functions;

public interface IMappingFunction
{
    public string? Execute(List<string?> parameters);
}

