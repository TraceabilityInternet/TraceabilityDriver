using TraceabilityDriver.Models.Mapping;

namespace TraceabilityDriver.Services;

/// <summary>
/// The service for merging events together.
/// </summary>
public class EventsMergerService
{
    private readonly ILogger<EventsMergerService> _logger;

    public EventsMergerService(ILogger<EventsMergerService> logger)
    {
        _logger = logger;
    }

    public async Task<List<CommonEvent>> MergeEventsAsync(TDMapping mapping, List<CommonEvent> events)
    {
        /// TODO: Implement the logic to merge the events together.
        return events;  
    }
}

