using System.Collections.Concurrent;
using TraceabilityDriver.Services.Mapping.Functions;

namespace TraceabilityDriver.Services.Mapping;

/// <summary>
/// A factory for creating mapping functions.
/// </summary>
public class MappingFunctionFactory
{
    private readonly ILogger<MappingFunctionFactory> _logger;
    private readonly IServiceProvider _serviceProvider;

    private readonly object _lock = new();
    private readonly ConcurrentDictionary<string, IMappingFunction> _mappingFunctions = new();

    public MappingFunctionFactory(IServiceProvider serviceProvider, ILogger<MappingFunctionFactory> logger)
    {
        _serviceProvider = serviceProvider;
        _logger = logger;
    }

    /// <summary>
    /// Creates a mapping function.
    /// </summary>
    /// <param name="functionName">The name of the function.</param>
    public IMappingFunction Create(string functionName)
    {
        functionName = functionName.Trim().ToLower();

        if (_mappingFunctions.TryGetValue(functionName, out var function))
        {
            return function;
        }

        lock (_lock)
        {
            if (_mappingFunctions.TryGetValue(functionName, out function))
            {
                return function;
            }

            function = Construct(functionName);
            _mappingFunctions.TryAdd(functionName, function);
            return function;
        }
    }

    /// <summary>
    /// Constructs a mapping function.
    /// </summary>
    /// <param name="functionName">The name of the function.</param>
    private IMappingFunction Construct(string functionName)
    {
        switch (functionName)
        {
            case "dictionary":
                var dictionaryFunction = _serviceProvider.GetRequiredService<DictionaryMappingFunction>();
                dictionaryFunction.Initialize();
                return dictionaryFunction;
            case "lotnumber":
                return _serviceProvider.GetRequiredService<LotNumberMappingFunction>();
            default:
                throw new NotImplementedException($"The mapping function {functionName} is not implemented.");
        }
    }
}
