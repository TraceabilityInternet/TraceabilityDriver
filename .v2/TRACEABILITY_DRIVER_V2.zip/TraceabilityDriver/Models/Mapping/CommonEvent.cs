namespace TraceabilityDriver.Models.Mapping;

/// <summary>
/// The common event model that data from the database is mapped to
/// then the common event is used to create an event in the event store.
/// </summary>
public class CommonEvent
{
    /// <summary>
    /// The type of the event.
    /// </summary>
    public string EventType { get; set; } = string.Empty;

    /// <summary>
    /// The time of the event.
    /// </summary>
    public DateTimeOffset EventTime { get; set; }

    /// <summary>
    /// The identifiers for the event.
    /// </summary>
    public Dictionary<string, object> Identifiers { get; set; } = new ();

    /// <summary>
    /// The data for the event.
    /// </summary>
    public Dictionary<string, object> Data { get; set; } = new ();
}

