using NUnit.Framework;

namespace TraceabilityDriver.Tests
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
            // Setup code that runs before each test
        }

        [Test]
        public void Test1()
        {
            // A simple test
            Assert.Pass("Test passed!");
        }
    }
} 